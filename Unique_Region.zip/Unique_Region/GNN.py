import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch_geometric.data import Data
from torch_geometric.nn import GINConv
from scipy.spatial import Delaunay
from sklearn.preprocessing import LabelEncoder
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv(r'D:\biostat article\single cell lab\Dryad\23_09_CODEX_HuBMAP_alldata_Dryad_merged.csv')

unique_regions = df['unique_region'].unique()

selected_regions = unique_regions[:9]

# Loop selected unique regions
for region in selected_regions:
    print(f"Processing unique region: {region}")
    
    region_df = df[df['unique_region'] == region]
    
    # Extract cell coordinates and features
    cell_coordinates = region_df[['x', 'y']].values
    features = region_df[['CD31', 'CD4', 'CD8', 'CD11c', 'CD44', 'CD16', 'CD3', 'CD19', 'CD45', 'CD56', 'CD69', 'Ki67']].values
    
    # Step 1 Delaunay visualization 
    sample_size = min(5000, len(cell_coordinates))
    np.random.seed(42)
    sample_indices = np.random.choice(len(cell_coordinates), size=sample_size, replace=False)
    sampled_coordinates = cell_coordinates[sample_indices]
    
    tri = Delaunay(sampled_coordinates)
    
    plt.figure(figsize=(10, 10))
    plt.triplot(sampled_coordinates[:, 0], sampled_coordinates[:, 1], tri.simplices, color='black', linewidth=0.5, alpha=0.6)
    plt.scatter(sampled_coordinates[:, 0], sampled_coordinates[:, 1], color='red', s=2, alpha=0.8)  
    
    plt.title(f'Delaunay Triangulation of Sampled Cell Coordinates for {region}')
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')
    plt.xlim(0, 9100)
    plt.ylim(0, 9100)
    plt.show()
    
    # Step 2 Construct edge using Delaunay triangulation
    tri_full = Delaunay(cell_coordinates)
    edges = []
    for simplex in tri_full.simplices:
        for i in range(len(simplex)):
            for j in range(i + 1, len(simplex)):
                edges.append([simplex[i], simplex[j]])
    
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
    x = torch.tensor(features, dtype=torch.float)
    
    label_encoder = LabelEncoder()
    labels = label_encoder.fit_transform(region_df['Cell Type'])  
    y = torch.tensor(labels, dtype=torch.long)
    
    data = Data(x=x, edge_index=edge_index, y=y)
    
    class GINModel(nn.Module):
        def __init__(self, input_dim, hidden_dim, output_dim):
            super(GINModel, self).__init__()
            self.conv1 = GINConv(nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim)
            ))
            self.conv2 = GINConv(nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim)
            ))
            self.conv3 = GINConv(nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim)
            ))
            self.fc = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, output_dim)
            )
        
        def forward(self, data):
            x, edge_index = data.x, data.edge_index
            x = self.conv1(x, edge_index)
            x = self.conv2(x, edge_index)
            x = self.conv3(x, edge_index)
            x = self.fc(x)
            return x
    
    # Step 4 GNN 
    input_dim = features.shape[1]
    hidden_dim = 64
    output_dim = len(label_encoder.classes_)
    
    model = GINModel(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim)
    print(model)
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    data = data.to(device)
    
    epochs = 20  
    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        
        out = model(data)
        loss = criterion(out, data.y)
        
        loss.backward()
        optimizer.step()
        
        print(f"Epoch {epoch+1}, Loss: {loss.item():.4f}")
    
    # Step 5 Model and Predictions
    model.eval()
    with torch.no_grad():
        predictions = model(data)
        predicted_labels = predictions.argmax(dim=1).cpu().numpy()
    
    region_df['Predicted Cell Type'] = label_encoder.inverse_transform(predicted_labels)
    
    # Step 6: Plot sampled data 
    data_sampled = region_df.sample(frac=0.2, random_state=42)
    
    colors_dict = {
        'NK': '#1f77b4',
        'Enterocyte': '#1f77b4',
        'MUC1+ Enterocyte': '#aec7e8',
        'TA': '#ff7f0e',
        'CD66+ Enterocyte': '#ffbb78',
        'Paneth': '#2ca02c',
        'Smooth Muscle': '#98df8a',
        'M1 Macrophage': '#d62728',
        'Goblet': '#ff9896',
        'Neuroendocrine': '#9467bd',
        'CD57+ B': '#c5b0d5',
        'Lymphatic': '#8c564b',
        'CD8+ T': '#c49c94',
        'DC': '#e377c2',
        'M2 Macrophage': '#f7b6d2',
        'B': '#7f7f7f',
        'Neutrophil': '#bcbd22',
        'Endothelial': '#dbdb8d',
        'Cycling TA': '#17becf',
        'Plasma': '#9edae5',
        'CD4+ T': '#f0e442',
        'Stroma': '#d62728',
        'Nerve': '#2ca02c',
        'ICC': '#1f77b4',
        'CD7+ Immune': '#17becf'
    }
    
    plt.figure(figsize=(24, 20))
    for cell_type in data_sampled['Predicted Cell Type'].unique():
        if cell_type in colors_dict:
            subset = data_sampled[data_sampled['Predicted Cell Type'] == cell_type]
            plt.scatter(subset['x'], subset['y'], label=cell_type, color=colors_dict[cell_type], s=4, alpha=0.7, edgecolor='none')
    
    plt.title(f'Zoomed-in Choropleth Map of Predicted Cell Types for unique region {region}')
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')
    plt.xlim(0, 9100)
    plt.ylim(0, 9100)
    
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), title='Cell Types', markerscale=6, fontsize='small', frameon=True)
    plt.show()
